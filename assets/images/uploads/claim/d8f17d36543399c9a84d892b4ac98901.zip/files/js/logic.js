
$("#submit-btn").click( function(event) {
  event.preventDefault();
 });
 
 function handleFileSelect(evt) {debugger
   var hours = document.getElementById('hours').value;
     var date = document.getElementById('date').value;
     var accomplished = document.getElementById('accomplished').value;
     var department = document.getElementById('department').value;
     var gender = document.getElementById('gender').value; 
    var image = document.getElementById('files').value;

    myArray = {"hours":hours,"date":date,"accomplished":accomplished,"department":department,
     "gender":gender,"image":image};
            nmyArray =  JSON.stringify(myArray);
            fmyArray = nmyArray.replace(']','');
            farray ='['+fmyArray+']';
            fdata =  JSON.stringify(localStorage.setItem('work',farray));
            location.reload();

    //localStorage.setItem("input", JSON.stringify($("#tracker").serializeArray()));

     /*var files = evt.target.files; 
     for (var i = 0, f; f = files[i]; i++) {
       if (!f.type.match('image.*')) {
         continue;
       }
 
       var reader = new FileReader();
 
       reader.onload = (function(theFile) {
         return function(e) {
           localStorage.setItem('img', e.target.result);
            
         };
       })(f);
       reader.readAsDataURL(f);
     }*/
   }
 
 function localStore(event) {
     debugger
     var hours = document.getElementById('hours').value;
     var date = document.getElementById('date').value;
     var accomplished = document.getElementById('accomplished').value;
     var department = document.getElementById('department').value;
     var gender = document.getElementById('gender').value;
 
     /*localStorage.setItem("hours", hours);
     localStorage.setItem("date", date);
     localStorage.setItem("accomplished", accomplished);
     localStorage.setItem("department", department);
     localStorage.setItem("gender", gender);*/

    /* myArray = {"hours":hours,"date":date,"accomplished":accomplished,"department":department,
     "gender":gender};
            nmyArray =  JSON.stringify(myArray);
            fmyArray1 = nmyArray.replace('[','');
            fmyArray = fmyArray1.replace(']','');
            farray ='['+fmyArray1+','+fmyArray+']';
            fdata =  JSON.stringify(localStorage.setItem('work',farray));
            location.reload();*/

             localStorage.setItem("input", JSON.stringify($("#tracker").serializeArray()));
 
     var table = document.getElementById("myLog");

     var row = table.insertRow(1);
     var cell1 = row.insertCell(0);
     var cell2 = row.insertCell(1);
     var cell3 = row.insertCell(2);
     var cell4 = row.insertCell(3);
     var cell5 = row.insertCell(4);
     var cell6 = row.insertCell(5);
     //var cell7 = row.insertCell(6);
     cell1.innerHTML = localStorage.date;
     cell2.innerHTML = localStorage.accomplished;
     cell3.innerHTML = localStorage.hours;
     cell4.innerHTML = localStorage.department;
     cell5.innerHTML = localStorage.gender;
     cell6.innerHTML = ['<img class="thumb" src="', localStorage.img,
                             '" title="test"/>'].join('');
    // cell7.innerHTML = '<input  class="btn btn-danger" id="delete-row-btn" type="button" value="X" onclick="deleteRow(this)"/>';
     document.getElementById("NDA").innerHTML = "";
 }
 
 function showdata(){
   if(localStorage.date)
   {
     var table = document.getElementById("myLog");
     var row = table.insertRow(1);
     var cell1 = row.insertCell(0);
     var cell2 = row.insertCell(1);
     var cell3 = row.insertCell(2);
     var cell4 = row.insertCell(3);
     var cell5 = row.insertCell(4);
     var cell6 = row.insertCell(5);
     var cell7 = row.insertCell(6);
     cell1.innerHTML = localStorage.date;
     cell2.innerHTML = localStorage.accomplished;
     cell3.innerHTML = localStorage.hours;
     cell4.innerHTML = localStorage.department;
     cell5.innerHTML = localStorage.gender;
     cell6.innerHTML = ['<img class="thumb" src="', localStorage.img,
                             '" title="test" onclick="openModal();" class="hover-shadow"/><div id="myModal" class="modal"><span class="close cursor" onclick="closeModal()">&times;</span><div class="modal-content"><div class="mySlides"><img src="', localStorage.img,
                             '" style="width:100%"></div></div>'].join('');
     cell7.innerHTML = '<input class="btn btn-danger" id="delete-row-btn" type="button" value="X" onclick="deleteRow(this)"/>';
     document.getElementById("NDA").innerHTML = "";
   }
   else
   {
    document.getElementById("NDA").innerHTML = "<span>NO DATA FOUND</span>";
   }
 }

 function openModal() {
  document.getElementById("myModal").style.display = "block";
}

function closeModal() {
  document.getElementById("myModal").style.display = "none";
}
 
 function deleteRow(elem) {
   var table = elem.parentNode.parentNode.parentNode;
   var rowCount = table.rows.length;
   if(rowCount === 1) {
     alert('Cannot delete the last row');
     return;
   }
   var row = elem.parentNode.parentNode; 
   row.parentNode.removeChild(row); 
   if(localStorage.clear())
   {
    document.getElementById("NDA").innerHTML = "<span>NO DATA FOUND</span>";
   }
 }
 showdata();
 document.getElementById('files').addEventListener('change', handleFileSelect, false);


 $(document).on('click', '[data-toggle="lightbox"]', function(event) {
                event.preventDefault();
                $(this).ekkoLightbox();
            });