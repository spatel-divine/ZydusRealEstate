
$("#submit-btn").click( function(event) {
  event.preventDefault();
 });

/*function imagebase64(images) {debugger
  showImages();

  $("body").on("change", ".file-upload", function() {
    var $input = $(this);
    var file = $input[0].files[0];

    var reader = new FileReader();
    reader.onload = function() {
      var images = JSON.parse(localStorage.getItem('images')) || [];
      images[$input.index('.file-upload')] = reader.result;
     // localStorage.setItem('images', JSON.stringify(images));
      showImages(images);
    }
    reader.readAsDataURL(file);
  });
}*/

function showImages(content) {
  $('.image').empty();
  var images = content || JSON.parse(localStorage.getItem('images')) || [];
  images.forEach(function(image, i) {
    $('<img height="30%" width="30%"/>').prop('src', image).appendTo($('.image').eq(i));
  })
}

function clearall()
{
  localStorage.clear();
  location.reload();
}

var filesSelected = '';



 /*function handleFileSelect(evt) {
     var files = evt.target.files; 
     for (var i = 0, f; f = files[i]; i++) {
       if (!f.type.match('image.*')) {
         continue;
       }
 
       var reader = new FileReader();
 
       reader.onload = (function(theFile) {
         return function(e) {
           //localStorage.setItem('img', e.target.result);
         };
       })(f);
       reader.readAsDataURL(f);
     }
   }*/


   $(document).ready(function() {
  var newArr = JSON.parse(window.localStorage.getItem('work'));
  if(newArr !== '' || newArr !== null)
  {
    var length = newArr.length;
   //console.log(length)
   var result = {};
  for (var i = 0, len = length; i < length; i++) {

       var table = document.getElementById("myLog");
           var row = table.insertRow(1);
       var cell1 = row.insertCell(0);
       var cell2 = row.insertCell(1);
       var cell3 = row.insertCell(2);
       var cell4 = row.insertCell(3);
       var cell5 = row.insertCell(4);
       var cell6 = row.insertCell(5);
       var cell7 = row.insertCell(6);
       var cell8 = row.insertCell(7);
       cell1.innerHTML = newArr[i].marks;
       cell2.innerHTML = newArr[i].date;
       cell3.innerHTML = newArr[i].accomplished;
       cell4.innerHTML = newArr[i].department;
       cell5.innerHTML = newArr[i].gender; 
       cell6.innerHTML = '<img src="'+newArr[i].img1+'" style="width:100%;">';
       cell7.innerHTML = '<img src="data:image/png;base64,'+newArr[i].img2+'" style="width:100%;">';
       cell8.innerHTML = '<img src="data:image/png;base64,'+newArr[i].img3+'" style="width:100%;">';

     }   
  }
   
  });

   /*function imagebase64(evt){debugger
    var input = document.querySelector('input[type=file]');
       var file = input.files[0],
      reader = new FileReader();

      reader.result;
      reader.readAsDataURL(file);

      var img1 = reader.result.replace(/^data:.+;base64,/, '');

   }*/

   
 function localStore(event) {
     debugger

   
    

//showdata();
     
  
             // var imgurl;
    
        var imgurl = encodeImageFileAsURL('upload1');
          var imgurl2 = encodeImageFileAsURL('upload2');
          var imgurl3 =  encodeImageFileAsURL('upload3');

        //imgurl = abc;

      var marks = document.getElementById('marks').value;
     var date = document.getElementById('date').value;
     var accomplished = document.getElementById('accomplished').value;
     var department = document.getElementById('department').value;
     var gender = $('input[name="gender"]:checked').val();


    

              var x = document.getElementById("myLog").rows.length;

        if(x>=1){
                var oldItems = JSON.parse(localStorage.getItem('work')) || [];
                var newItem = 
                {
                  "marks":marks,
                  "date":date,
                  "accomplished":accomplished,
                  "department":department,
                  "gender":gender,
                  "img1":imgurl,
                  "img2":imgurl2,
                  "img3":imgurl3
                };
                oldItems.push(newItem);
                localStorage.setItem('work', JSON.stringify(oldItems));
                }else{
                myArray = {"marks":marks,"date":date,"accomplished":accomplished,"department":department,
                "gender":gender,"img1":imgurl,"img2":imgurl2,"img3":imgurl3};
                nmyArray1 =  JSON.stringify(myArray);
                farray ='['+nmyArray1+']';
                fdata =  JSON.stringify(localStorage.setItem('work',farray));
                }
              location.reload();

     


      


             

}

function encodeImageFileAsURL(id1) {
  var srcData = '';
debugger
    var filesSelected = document.getElementById(id1).files;
    if (filesSelected.length > 0) {
      var fileToLoad = filesSelected[0];

      var fileReader = new FileReader();

      fileReader.onload = function(fileLoadedEvent) {
         srcData = fileLoadedEvent.target.result; // <--- data: base64

        //return srcData;
        //alert("Converted Base64 version is " + document.getElementById("imgTest").innerHTML);
        //console.log("Converted Base64 version is " + document.getElementById("imgTest").innerHTML);
      }
      fileReader.readAsDataURL(fileToLoad);
    }
    return srcData;
  }


    
     document.getElementById("NDA").innerHTML = "";

 function deleteRow(elem) {
   var table = elem.parentNode.parentNode.parentNode;
   var rowCount = table.rows.length;
   if(rowCount === 1) {
     alert('Cannot delete the last row');
     return;
   }
   var row = elem.parentNode.parentNode; 
   row.parentNode.removeChild(row); 
   if(localStorage.clear())
   {
    document.getElementById("NDA").innerHTML = "<span>NO DATA FOUND</span>";
   }
 }
 //showdata();


 //document.getElementById('files').addEventListener('change', handleFileSelect, false);