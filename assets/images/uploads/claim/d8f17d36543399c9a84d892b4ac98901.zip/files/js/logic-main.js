
$("#submit-btn").click( function(event) {
  event.preventDefault();
 });

function showImages(content) {
  $('.image').empty();
  var images = content || JSON.parse(localStorage.getItem('work')) || [];
  images.forEach(function(image, i) {
    $('<img height="30%" width="30%"/>').prop('src', image).appendTo($('.image').eq(i));
  })
}

function clearall()
{
  localStorage.clear();
  location.reload();
}

var filesSelected = '';



   $(document).ready(function() {debugger
  var newArr = JSON.parse(window.localStorage.getItem('work'));
  if(newArr !== '' || newArr !== null)
  {
    var length = newArr.length;
   //console.log(length)
   var result = {};
  for (var i = 0, len = length; i < length; i++) {

       var table = document.getElementById("myLog");
           var row = table.insertRow(1);
       var cell1 = row.insertCell(0);
       var cell2 = row.insertCell(1);
       var cell3 = row.insertCell(2);
       var cell4 = row.insertCell(3);
       var cell5 = row.insertCell(4);
       var cell6 = row.insertCell(5);
       var cell7 = row.insertCell(6);
       var cell8 = row.insertCell(7);
       cell1.innerHTML = newArr[i].marks;
       cell2.innerHTML = newArr[i].date;
       cell3.innerHTML = newArr[i].accomplished;
       cell4.innerHTML = newArr[i].department;
       cell5.innerHTML = newArr[i].gender; 
       if(newArr[i].img1 !== ""){
       	cell6.innerHTML = '<a href="'+newArr[i].img1+'"><img src="'+newArr[i].img1+'" style="width:100%;" class="thumbnail"></a>';
       }else{
       	cell6.innerHTML = 'Picture Not Available';
       }
        if(newArr[i].img2 !== ""){
       		cell7.innerHTML = '<a href="'+newArr[i].img2+'"><img src="'+newArr[i].img2+'" style="width:100%;" class="thumbnail"></a>';
       		
       }
       else{
       	cell7.innerHTML = 'Picture Not Available';
       }
        if(newArr[i].img3 !== ""){

      	 cell8.innerHTML = '<a href="'+newArr[i].img3+'"><img src="'+newArr[i].img3+'" style="width:100%;" class="thumbnail"></a>';
        }
       else{
       	cell8.innerHTML = 'Picture Not Available';
       }
     }   
  }
  $('img.thumbnail').imgZoom();
  });


 function localStore(event) {
     debugger

    encodeImageFileAsURL('upload1');
    encodeImageFileAsURL('upload2');
    encodeImageFileAsURL('upload3');

    setTimeout(function(){ callback(); }, 3000);


//showdata();
     var marks = document.getElementById('marks').value;
     var date = document.getElementById('date').value;
     var accomplished = document.getElementById('accomplished').value;
     var department = document.getElementById('department').value;
     var gender = $('input[name="gender"]:checked').val();


    

              var x = document.getElementById("myLog").rows.length;
             //console.log(x);

             
      function callback()
      {
        

        if(x>=1){
                var oldItems = JSON.parse(localStorage.getItem('work')) || [];
                var newItem = 
                {
                  "marks":marks,
                  "date":date,
                  "accomplished":accomplished,
                  "department":department,
                  "gender":gender,
                  "img1":imgdata1,
                  "img2":imgdata2,
                  "img3":imgdata3
                };
                oldItems.push(newItem);
                localStorage.setItem('work', JSON.stringify(oldItems));
                }else{
                myArray = {"marks":marks,"date":date,"accomplished":accomplished,"department":department,
                "gender":gender,"img1":imgurl,"img2":imgdata2,"img3":imgdata3};
                nmyArray1 =  JSON.stringify(myArray);
                farray ='['+nmyArray1+']';
                fdata =  JSON.stringify(localStorage.setItem('work',farray));
                }
              location.reload();
      } 

var imgdata1 = '';
var imgdata2 = '';
var imgdata3 = '';

function encodeImageFileAsURL(id1) {
debugger
    var filesSelected = document.getElementById(id1).files;
    if (filesSelected.length > 0) {
      var fileToLoad = filesSelected[0];

      var fileReader = new FileReader();

      fileReader.onload = function(fileLoadedEvent) {
         srcData = fileLoadedEvent.target.result; // <--- data: base64

        callback_2(id1,srcData);
        //alert("Converted Base64 version is " + document.getElementById("imgTest").innerHTML);
        //console.log("Converted Base64 version is " + document.getElementById("imgTest").innerHTML);
      }
      fileReader.readAsDataURL(fileToLoad);
    }
  }

      function callback_2(id1,srcData)
      {
        if(id1 == 'upload1')
        {
          imgdata1 = srcData;
        }

        if(id1 == 'upload2')
        {
          imgdata2 = srcData;
        }

        if(id1 == 'upload3')
        {
          imgdata3 = srcData;
        }

      }


             

}


    
     document.getElementById("NDA").innerHTML = "";

 function deleteRow(elem) {
   var table = elem.parentNode.parentNode.parentNode;
   var rowCount = table.rows.length;
   if(rowCount === 1) {
     alert('Cannot delete the last row');
     return;
   }
   var row = elem.parentNode.parentNode; 
   row.parentNode.removeChild(row); 
   if(localStorage.clear())
   {
    document.getElementById("NDA").innerHTML = "<span>NO DATA FOUND</span>";
   }
 }
 //showdata();


 //document.getElementById('files').addEventListener('change', handleFileSelect, false);